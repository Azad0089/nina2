<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiKeyMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $expected = (string) config('simulator.api_key');
        $provided = (string) $request->header('X-API-Key', '');
        if ($expected === '' || $expected === 'change-me' || !hash_equals($expected, $provided)) {
            return response()->json(['error' => ['code' => 'AUTHENTICATION_FAILED', 'message' => 'Invalid or missing API key.']], 401);
        }
        return $next($request);
    }
}
