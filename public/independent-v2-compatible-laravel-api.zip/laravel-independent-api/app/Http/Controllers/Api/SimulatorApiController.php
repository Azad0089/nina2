<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SimulatorAccount;
use App\Models\SimulatorMovement;
use App\Models\SimulatorTransaction;
use App\Models\SimulatorBankSession;
use App\Services\SimulatorService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SimulatorApiController extends Controller
{
    public function __construct(private SimulatorService $service) {}

    public function banks() { return response()->json(['data'=>[
        ['code'=>'garanti','name'=>'Garanti BBVA','iban_prefix'=>'TR__0062','swift_code'=>'TGBATRIS','supports_fast'=>true,'supports_eft'=>true,'supports_havale'=>true],
        ['code'=>'isbank','name'=>'Türkiye İş Bankası','iban_prefix'=>'TR__0064','swift_code'=>'ISBKTRIS','supports_fast'=>true,'supports_eft'=>true,'supports_havale'=>true],
        ['code'=>'akbank','name'=>'Akbank','iban_prefix'=>'TR__0046','swift_code'=>'AKBKTRIS','supports_fast'=>true,'supports_eft'=>true,'supports_havale'=>true],
        ['code'=>'ziraat','name'=>'Ziraat Bankası','iban_prefix'=>'TR__0010','swift_code'=>'TCZBTR2A','supports_fast'=>true,'supports_eft'=>true,'supports_havale'=>true],
    ],'total'=>4]); }

    public function accounts(Request $request) {
        $q=SimulatorAccount::query(); if ($request->has('active')) $q->where('is_active',$request->boolean('active'));
        $rows=$q->orderBy('id')->get()->map(fn($a)=>['id'=>$a->id,'name'=>$a->name,'bank_code'=>$a->bank_code,'iban'=>$a->iban,'account_holder'=>$a->account_holder,'is_active'=>$a->is_active,'capabilities'=>$a->capabilities ?? ['deposits'=>true,'withdrawals'=>true]])->values();
        return response()->json(['data'=>$rows,'total'=>$rows->count()]);
    }

    public function inquiry(Request $request) {
        $q=SimulatorAccount::query(); if ($request->filled('account_id')) $q->where('id',$request->input('account_id')); if ($request->filled('iban')) $q->where('iban',$request->input('iban'));
        $accounts=$q->get()->map(fn($a)=>['account_id'=>$a->id,'iban'=>$a->iban,'account_holder'=>$a->account_holder,'balance'=>(string)$a->balance,'currency'=>config('simulator.currency','TRY'),'is_active'=>$a->is_active])->values();
        return response()->json(['data'=>$accounts,'total'=>$accounts->count()]);
    }

    public function movements(Request $request) {
        $q=SimulatorMovement::query()->orderByDesc('occurred_at');
        if ($request->filled('account_id')) $q->where('account_id',$request->input('account_id'));
        if ($request->filled('from')) $q->where('occurred_at','>=',$request->input('from'));
        if ($request->filled('to')) $q->where('occurred_at','<=',$request->input('to'));
        $perPage=min(max((int)$request->input('per_page',20),1),100); $page=$q->paginate($perPage);
        return response()->json(['data'=>$page->getCollection()->map(fn($m)=>['id'=>$m->id,'account_id'=>$m->account_id,'transaction_id'=>$m->transaction_id,'direction'=>$m->direction,'amount'=>(string)$m->amount,'description'=>$m->description,'counterparty_iban'=>$m->counterparty_iban,'counterparty_name'=>$m->counterparty_name,'occurred_at'=>$m->occurred_at?->toISOString()]),'pagination'=>['current_page'=>$page->currentPage(),'per_page'=>$page->perPage(),'total'=>$page->total(),'last_page'=>$page->lastPage()]]);
    }

    public function autoWithdrawal(Request $request) { return response()->json($this->service->createWithdrawal($this->validatedWithdrawal($request),false),201); }
    public function manualWithdrawal(Request $request) { return response()->json($this->service->createWithdrawal($this->validatedWithdrawal($request,true),true),201); }

    private function validatedWithdrawal(Request $request, bool $manual=false): array {
        $rules=['ext_transaction_id'=>'required|string|max:128','receiver_iban'=>'required|string|max:64','receiver_name'=>'required|string|max:255','amount'=>['required','numeric','gt:0','regex:/^\d+(\.\d{1,2})?$/'],'callback_url'=>'nullable|url|max:2048','description'=>'nullable|string|max:1000'];
        if ($manual) { $rules['sender_iban']='required_without:account_id|nullable|string|max:64'; $rules['account_id']='required_without:sender_iban|nullable|integer'; }
        $data=$request->validate($rules);
        if ($manual && (isset($data['sender_iban']) === isset($data['account_id']))) abort(response()->json(['error'=>['code'=>'VALIDATION_ERROR','message'=>'Provide exactly one of sender_iban or account_id.']],422));
        return $data;
    }

    public function cancelWithdrawal(string $id) {
        $tx=SimulatorTransaction::where('uuid',$id)->orWhere('ext_transaction_id',$id)->first();
        if (!$tx) return response()->json(['error'=>['code'=>'NOT_FOUND','message'=>'Transaction not found.']],404);
        if ($tx->type!=='withdrawal') return response()->json(['error'=>['code'=>'BUSINESS_ERROR','message'=>'Only withdrawals can be cancelled.']],422);
        if ($tx->status!=='pending') return response()->json(['id'=>$tx->uuid,'status'=>'rejected','message'=>'Only pending withdrawals can be cancelled.'],409);
        $tx->status='cancelled'; $tx->completed_at=now(); $tx->save();
        return response()->json(['id'=>$tx->uuid,'status'=>'cancelled']);
    }

    public function transactions(Request $request) {
        $q=SimulatorTransaction::query()->orderByDesc('created_at');
        foreach (['type','status','ext_transaction_id'] as $key) if ($request->filled($key)) $q->where($key,$request->input($key));
        if ($request->filled('from')) $q->where('created_at','>=',$request->input('from')); if ($request->filled('to')) $q->where('created_at','<=',$request->input('to'));
        $perPage=min(max((int)$request->input('per_page',20),1),100); $p=$q->paginate($perPage);
        return response()->json(['data'=>$p->getCollection()->map(fn($t)=>$this->service->transactionPayload($t)),'pagination'=>['current_page'=>$p->currentPage(),'per_page'=>$p->perPage(),'total'=>$p->total(),'last_page'=>$p->lastPage()]]);
    }
    public function transaction(string $id) { $tx=SimulatorTransaction::where('uuid',$id)->orWhere('ext_transaction_id',$id)->first(); return $tx ? response()->json($this->service->transactionPayload($tx)) : response()->json(['error'=>['code'=>'NOT_FOUND','message'=>'Transaction not found.']],404); }
    public function receipt(string $id) { $tx=SimulatorTransaction::where('uuid',$id)->orWhere('ext_transaction_id',$id)->first(); if(!$tx) return response()->json(['error'=>['code'=>'NOT_FOUND','message'=>'Transaction not found.']],404); return response()->json(['id'=>$tx->uuid,'ext_transaction_id'=>$tx->ext_transaction_id,'status'=>$tx->status,'receipt_url'=>null,'message'=>'Simulated transactions do not have bank-issued receipts.']); }

    public function simulateDeposit(Request $request) {
        $d=$request->validate(['amount'=>['required','numeric','gt:0','regex:/^\d+(\.\d{1,2})?$/'],'sender_name'=>'required|string|max:255','sender_iban'=>'nullable|string|max:64','receiver_iban'=>'required|string|max:64','ext_transaction_id'=>'required|string|max:128']);
        if (SimulatorTransaction::where('ext_transaction_id',$d['ext_transaction_id'])->exists()) return response()->json(['error'=>['code'=>'DUPLICATE_REQUEST','message'=>'ext_transaction_id has already been used.']],422);
        $account=SimulatorAccount::where('iban',$d['receiver_iban'])->first();
        $tx=DB::transaction(function() use($d,$account){ $tx=SimulatorTransaction::create(['uuid'=>(string)Str::uuid(),'ext_transaction_id'=>$d['ext_transaction_id'],'type'=>'deposit','status'=>'success','amount'=>number_format((int)round(((float)$d['amount'])*100)/100,2,'.',''),'currency'=>config('simulator.currency','TRY'),'sender_iban'=>$d['sender_iban']??null,'sender_account_id'=>null,'receiver_iban'=>$d['receiver_iban'],'receiver_name'=>$account?->account_holder,'description'=>'Simulated deposit from '.$d['sender_name'],'metadata'=>['sender_name'=>$d['sender_name']],'completed_at'=>now()]); if($account){$balanceCents=(int)round(((float)$account->balance)*100)+(int)round(((float)$tx->amount)*100);$account->balance=number_format($balanceCents/100,2,'.','');$account->save();} SimulatorMovement::create(['account_id'=>$account?->id,'transaction_id'=>$tx->id,'direction'=>'in','amount'=>$tx->amount,'description'=>$tx->description,'counterparty_iban'=>$d['sender_iban']??null,'counterparty_name'=>$d['sender_name'],'occurred_at'=>now()]); return $tx; });
        return response()->json(['transaction'=>$this->service->transactionPayload($tx),'simulated'=>true],201);
    }
    public function settle(string $id, Request $request) { $request->validate(['status'=>'required|in:success,fail']); $tx=SimulatorTransaction::where('uuid',$id)->orWhere('ext_transaction_id',$id)->first(); if(!$tx) return response()->json(['error'=>['code'=>'NOT_FOUND','message'=>'Transaction not found.']],404); return response()->json($this->service->settle($tx,$request->input('status'))); }
    /** Demo-only login. Credentials are checked against environment config; no bank app is contacted. */
    public function bankLogin(Request $request) {
        $data = $request->validate(['username'=>'required|string|max:190','password'=>'required|string|max:500','bank_code'=>'nullable|string|max:64']);
        $expectedUser = (string) config('simulator.bank_username');
        $expectedPassword = (string) config('simulator.bank_password');
        if ($expectedUser === '' || $expectedPassword === '' || !hash_equals($expectedUser, $data['username']) || !hash_equals($expectedPassword, $data['password'])) {
            return response()->json(['error'=>['code'=>'AUTHENTICATION_FAILED','message'=>'Invalid demo banking credentials.']], 401);
        }
        $plainToken = Str::random(64);
        $ttl = max(5, (int) config('simulator.session_ttl_minutes', 30));
        SimulatorBankSession::create(['token_hash'=>hash('sha256',$plainToken),'username'=>$data['username'],'bank_code'=>$data['bank_code'] ?? null,'status'=>'active','expires_at'=>now()->addMinutes($ttl),'last_seen_at'=>now()]);
        return response()->json(['token'=>$plainToken,'token_type'=>'Bearer','expires_in'=>$ttl*60,'expires_at'=>now()->addMinutes($ttl)->toISOString(),'simulated'=>true], 201);
    }

    private function currentBankSession(Request $request): ?SimulatorBankSession {
        $token = (string) $request->header('X-Bank-Session', '');
        if ($token === '' && preg_match('/^Bearer\s+(.+)$/i', (string)$request->header('Authorization',''), $m)) $token = $m[1];
        if ($token === '') return null;
        return SimulatorBankSession::where('token_hash',hash('sha256',$token))->where('status','active')->where('expires_at','>',now())->first();
    }

    public function bankSession(Request $request) {
        $session = $this->currentBankSession($request);
        if (!$session) return response()->json(['error'=>['code'=>'SESSION_EXPIRED','message'=>'Missing, invalid, or expired demo bank session.']], 401);
        $session->last_seen_at = now(); $session->save();
        return response()->json(['status'=>'active','username'=>$session->username,'bank_code'=>$session->bank_code,'expires_at'=>$session->expires_at->toISOString(),'last_seen_at'=>$session->last_seen_at->toISOString(),'simulated'=>true]);
    }

    public function refreshBankSession(Request $request) {
        $session = $this->currentBankSession($request);
        if (!$session) return response()->json(['error'=>['code'=>'SESSION_EXPIRED','message'=>'Missing, invalid, or expired demo bank session.']], 401);
        $ttl = max(5, (int) config('simulator.session_ttl_minutes', 30));
        $session->expires_at = now()->addMinutes($ttl); $session->last_seen_at = now(); $session->save();
        return response()->json(['status'=>'active','expires_in'=>$ttl*60,'expires_at'=>$session->expires_at->toISOString(),'simulated'=>true]);
    }

    public function bankLogout(Request $request) {
        $session = $this->currentBankSession($request);
        if (!$session) return response()->json(['error'=>['code'=>'SESSION_EXPIRED','message'=>'Missing, invalid, or expired demo bank session.']], 401);
        $session->status='revoked'; $session->save();
        return response()->json(['status'=>'logged_out']);
    }

    public function accountBalance(int $id, Request $request) {
        if (!$this->currentBankSession($request)) return response()->json(['error'=>['code'=>'SESSION_EXPIRED','message'=>'A valid X-Bank-Session is required.']], 401);
        $account = SimulatorAccount::find($id);
        if (!$account) return response()->json(['error'=>['code'=>'ACCOUNT_NOT_FOUND','message'=>'Account not found.']],404);
        return response()->json(['account_id'=>$account->id,'iban'=>$account->iban,'account_holder'=>$account->account_holder,'available_balance'=>(string)$account->balance,'ledger_balance'=>(string)$account->balance,'currency'=>config('simulator.currency','TRY'),'simulated'=>true]);
    }

    public function accountActivity(int $id, Request $request) {
        if (!$this->currentBankSession($request)) return response()->json(['error'=>['code'=>'SESSION_EXPIRED','message'=>'A valid X-Bank-Session is required.']], 401);
        if (!SimulatorAccount::whereKey($id)->exists()) return response()->json(['error'=>['code'=>'ACCOUNT_NOT_FOUND','message'=>'Account not found.']],404);
        $q=SimulatorMovement::where('account_id',$id)->orderByDesc('occurred_at');
        if ($request->filled('from')) $q->where('occurred_at','>=',$request->input('from'));
        if ($request->filled('to')) $q->where('occurred_at','<=',$request->input('to'));
        $perPage=min(max((int)$request->input('per_page',20),1),100); $p=$q->paginate($perPage);
        return response()->json(['account_id'=>$id,'data'=>$p->getCollection()->map(fn($m)=>['id'=>$m->id,'transaction_id'=>$m->transaction_id,'direction'=>$m->direction,'amount'=>(string)$m->amount,'description'=>$m->description,'counterparty_iban'=>$m->counterparty_iban,'counterparty_name'=>$m->counterparty_name,'occurred_at'=>$m->occurred_at?->toISOString()])->values(),'pagination'=>['current_page'=>$p->currentPage(),'per_page'=>$p->perPage(),'total'=>$p->total(),'last_page'=>$p->lastPage()],'simulated'=>true]);
    }

    public function createTransfer(Request $request) {
        if (!$this->currentBankSession($request)) return response()->json(['error'=>['code'=>'SESSION_EXPIRED','message'=>'A valid X-Bank-Session is required.']], 401);
        $d=$request->validate(['ext_transaction_id'=>'required|string|max:128','account_id'=>'required|integer|exists:simulator_accounts,id','receiver_iban'=>'required|string|max:64','receiver_name'=>'required|string|max:255','amount'=>['required','numeric','gt:0','regex:/^\\d+(\\.\\d{1,2})?$/'],'description'=>'nullable|string|max:1000','callback_url'=>'nullable|url|max:2048']);
        $account=SimulatorAccount::find($d['account_id']);
        if (!$account || !$account->is_active) return response()->json(['error'=>['code'=>'ACCOUNT_NOT_FOUND','message'=>'Source account not found or inactive.']],422);
        if (SimulatorTransaction::where('ext_transaction_id',$d['ext_transaction_id'])->exists()) return response()->json(['error'=>['code'=>'DUPLICATE_REQUEST','message'=>'ext_transaction_id has already been used.']],422);
        $tx=SimulatorTransaction::create(['uuid'=>(string)Str::uuid(),'ext_transaction_id'=>$d['ext_transaction_id'],'type'=>'transfer','status'=>'pending','amount'=>number_format((float)$d['amount'],2,'.',''),'currency'=>config('simulator.currency','TRY'),'sender_iban'=>$account->iban,'sender_account_id'=>$account->id,'receiver_iban'=>$d['receiver_iban'],'receiver_name'=>$d['receiver_name'],'description'=>$d['description']??null,'callback_url'=>$d['callback_url']??null,'metadata'=>['mode'=>'transfer']]);
        return response()->json($this->service->transactionPayload($tx)+['simulated'=>true],201);
    }

    public function health() { return response()->json(['status'=>'ok']); }
    public function ready() { try { DB::connection()->getPdo(); return response()->json(['status'=>'ready']); } catch(\Throwable $e) { return response()->json(['status'=>'not_ready'],503); } }
}
