<?php
namespace App\Services;

use App\Models\SimulatorAccount;
use App\Models\SimulatorMovement;
use App\Models\SimulatorTransaction;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SimulatorService
{
    public function createWithdrawal(array $data, bool $manual = false): array
    {
        if (SimulatorTransaction::where('ext_transaction_id', $data['ext_transaction_id'])->exists()) {
            abort(response()->json(['error'=>['code'=>'DUPLICATE_REQUEST','message'=>'ext_transaction_id has already been used.']],422));
        }
        $account = null;
        if ($manual) {
            $account = isset($data['account_id'])
                ? SimulatorAccount::find($data['account_id'])
                : SimulatorAccount::where('iban', $data['sender_iban'])->first();
            if (!$account || !$account->is_active) {
                abort(response()->json(['error'=>['code'=>'ACCOUNT_NOT_FOUND','message'=>'The selected sender account was not found or is inactive.']],422));
            }
        } else {
            $account = SimulatorAccount::where('is_active', true)->whereJsonContains('capabilities->withdrawals', true)->orderBy('id')->first();
        }
        $tx = DB::transaction(function () use ($data, $account) {
            return SimulatorTransaction::create([
                'uuid'=>(string) Str::uuid(), 'ext_transaction_id'=>$data['ext_transaction_id'],
                'type'=>'withdrawal', 'status'=>'pending', 'amount'=>$this->decimal((string)$data['amount']),
                'currency'=>config('simulator.currency','TRY'), 'sender_iban'=>$account?->iban,
                'sender_account_id'=>$account?->id, 'receiver_iban'=>$data['receiver_iban'],
                'receiver_name'=>$data['receiver_name'], 'description'=>$data['description'] ?? null,
                'callback_url'=>$data['callback_url'] ?? null,
                'metadata'=>['mode'=>$account ? ($manual?'manual':'auto') : 'auto','chunks'=>null],
            ]);
        });
        return $this->withdrawalPayload($tx);
    }

    private function decimal(string $value): string
    {
        [$whole, $fraction] = array_pad(explode('.', $value, 2), 2, '');
        return ltrim($whole, '0') === '' && $fraction === '' ? '0.00' : (ltrim($whole, '0') ?: '0') . '.' . str_pad(substr($fraction, 0, 2), 2, '0');
    }

    public function withdrawalPayload(SimulatorTransaction $tx): array
    {
        return ['id'=>$tx->uuid,'ext_transaction_id'=>$tx->ext_transaction_id,'status'=>$tx->status,
            'sender_iban'=>$tx->sender_iban,'sender_account_id'=>$tx->sender_account_id,
            'account_group_id'=>null,'transfer_type'=>null,'chunks'=>$tx->metadata['chunks'] ?? null,
            'havale_only_warning'=>null,'routing_rule_warning'=>null];
    }

    public function transactionPayload(SimulatorTransaction $tx): array
    {
        return ['id'=>$tx->uuid,'ext_transaction_id'=>$tx->ext_transaction_id,'type'=>$tx->type,'status'=>$tx->status,
            'amount'=>(string)$tx->amount,'currency'=>$tx->currency,'sender_iban'=>$tx->sender_iban,
            'receiver_iban'=>$tx->receiver_iban,'receiver_name'=>$tx->receiver_name,'description'=>$tx->description,
            'created_at'=>$tx->created_at?->toISOString(),'updated_at'=>$tx->updated_at?->toISOString(),
            'completed_at'=>$tx->completed_at?->toISOString()];
    }

    public function settle(SimulatorTransaction $tx, string $status): array
    {
        if (!in_array($status, ['success','fail'], true)) abort(response()->json(['error'=>['code'=>'VALIDATION_ERROR','message'=>'status must be success or fail.']],422));
        $statusFinal = $status;
        $alreadyFinal = false;
        $tx = DB::transaction(function () use ($tx, &$statusFinal, &$alreadyFinal) {
            $locked = SimulatorTransaction::whereKey($tx->id)->lockForUpdate()->firstOrFail();
            if ($locked->status !== 'pending') { $alreadyFinal = true; return $locked; }
            if ($statusFinal === 'success' && $locked->sender_account_id) {
                $account = SimulatorAccount::whereKey($locked->sender_account_id)->lockForUpdate()->first();
                if (!$account) { $statusFinal = 'fail'; }
                else {
                    $availableCents = (int) round(((float)$account->balance) * 100);
                    $amountCents = (int) round(((float)$locked->amount) * 100);
                    if ($availableCents < $amountCents) { $statusFinal = 'fail'; }
                    else {
                        $account->balance = number_format(($availableCents - $amountCents) / 100, 2, '.', ''); $account->save();
                        SimulatorMovement::create(['account_id'=>$account->id,'transaction_id'=>$locked->id,'direction'=>'out','amount'=>$locked->amount,'description'=>$locked->description ?? 'Simulated withdrawal','counterparty_iban'=>$locked->receiver_iban,'counterparty_name'=>$locked->receiver_name,'occurred_at'=>now()]);
                    }
                }
            }
            if ($statusFinal === 'success' && in_array($locked->type, ['transfer'], true)) {
                $receiver = SimulatorAccount::where('iban',$locked->receiver_iban)->lockForUpdate()->first();
                if ($receiver) {
                    $receiver->balance = number_format(((int)round(((float)$receiver->balance)*100) + (int)round(((float)$locked->amount)*100))/100,2,'.',''); $receiver->save();
                    SimulatorMovement::create(['account_id'=>$receiver->id,'transaction_id'=>$locked->id,'direction'=>'in','amount'=>$locked->amount,'description'=>$locked->description ?? 'Simulated incoming transfer','counterparty_iban'=>$locked->sender_iban,'counterparty_name'=>null,'occurred_at'=>now()]);
                }
            }
            $locked->status = $statusFinal; $locked->completed_at = now(); $locked->save();
            return $locked->fresh();
        });
        $delivered = null;
        if ($tx->callback_url) {
            try {
                $payload=['id'=>$tx->uuid,'ext_transaction_id'=>$tx->ext_transaction_id,'status'=>$tx->status,'amount'=>(string)$tx->amount,'type'=>$tx->type];
                $response=Http::timeout(5)->withHeaders(['X-Simulator-Signature'=>hash_hmac('sha256',json_encode($payload),config('simulator.callback_secret'))])->post($tx->callback_url,$payload);
                $delivered=$response->successful();
            } catch (\Throwable $e) { $delivered=false; }
        }
        return ['transaction'=>$this->transactionPayload($tx->fresh()),'already_final'=>$alreadyFinal,'callback_delivered'=>$delivered,'simulated'=>true];
    }

}
