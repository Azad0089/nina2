<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SimulatorTransaction extends Model
{
    protected $table = 'simulator_transactions';
    protected $fillable = ['uuid','ext_transaction_id','type','status','amount','currency','sender_iban','sender_account_id','receiver_iban','receiver_name','description','callback_url','metadata','completed_at'];
    protected $casts = ['amount'=>'decimal:2','metadata'=>'array','completed_at'=>'datetime'];
}
