<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SimulatorMovement extends Model
{
    protected $table = 'simulator_movements';
    protected $fillable = ['account_id','transaction_id','direction','amount','description','counterparty_iban','counterparty_name','occurred_at'];
    protected $casts = ['amount'=>'decimal:2','occurred_at'=>'datetime'];
}
