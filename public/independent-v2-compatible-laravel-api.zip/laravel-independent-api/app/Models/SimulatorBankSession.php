<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SimulatorBankSession extends Model
{
    protected $table = 'simulator_bank_sessions';
    protected $fillable = ['token_hash', 'username', 'bank_code', 'status', 'expires_at', 'last_seen_at', 'metadata'];
    protected $casts = ['expires_at' => 'datetime', 'last_seen_at' => 'datetime', 'metadata' => 'array'];
}
