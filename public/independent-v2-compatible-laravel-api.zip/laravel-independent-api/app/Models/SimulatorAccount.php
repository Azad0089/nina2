<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SimulatorAccount extends Model
{
    protected $table = 'simulator_accounts';
    protected $fillable = ['name','bank_code','iban','account_holder','balance','is_active','capabilities'];
    protected $casts = ['balance'=>'decimal:2','is_active'=>'boolean','capabilities'=>'array'];
}
