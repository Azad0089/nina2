# Independent Laravel API — V2-Compatible Simulation

## What this is
A standalone Laravel implementation of the documented V2 API contract. It does not call or require the original provider. Data is stored in your own Laravel database. It is simulation-only: no real deposits or bank transfers occur.

## Endpoint list
| Method | Path | Behaviour |
|---|---|---|
| GET | `/v2/banks` | Returns configured demo bank directory |
| GET | `/v2/accounts` | Lists local simulated bank accounts and capabilities |
| GET | `/v2/accounts/inquiry` | Returns local account balances and account info |
| GET | `/v2/accounts/movements` | Lists local movement ledger with pagination/filters |
| POST | `/v2/withdrawal/auto` | Creates a pending withdrawal and chooses an eligible local account |
| POST | `/v2/withdrawal/manual` | Creates a pending withdrawal from `sender_iban` or `account_id` |
| POST | `/v2/withdrawal/{id}/cancel` | Cancels a pending withdrawal |
| GET | `/v2/transactions` | Lists local transactions |
| GET | `/v2/transactions/{id}` | Gets transaction by UUID or external ID |
| GET | `/v2/transactions/{id}/receipt` | Returns simulated receipt metadata; no bank receipt exists |
| GET | `/health` | Application health response |
| GET | `/ready` | Checks database connectivity |
| POST | `/v2/simulator/deposits` | Local-only development endpoint to create a simulated deposit |
| POST | `/v2/simulator/transactions/{id}/settle` | Local-only development endpoint to settle a pending transaction |

The two `/simulator/*` routes are extra development tools and should be disabled or access-restricted in deployments exposed publicly.

## Authentication
Every `/v2/*` endpoint requires `X-API-Key`, compared in constant time against `SIMULATOR_API_KEY`. Health/readiness are public for monitoring. Set a long random key in `.env`; do not commit secrets.

## Withdrawal payload
Automatic:
```json
{
  "ext_transaction_id": "ORDER-12345",
  "receiver_iban": "TR330006100519786457841326",
  "receiver_name": "Demo Recipient",
  "amount": "1500.00",
  "callback_url": "https://example.test/webhooks/withdrawal",
  "description": "Test withdrawal"
}
```
Manual requires the same fields and exactly one of `sender_iban` or `account_id`.

Successful creation responds with HTTP `201` and fields `id`, `ext_transaction_id`, `status: pending`, `sender_iban`, `sender_account_id`, `account_group_id`, `transfer_type`, `chunks`, `havale_only_warning`, and `routing_rule_warning`. A repeated `ext_transaction_id` returns `422` with `DUPLICATE_REQUEST`.

## Simulation workflow
1. Seed demo accounts using `php artisan db:seed --class=SimulatorAccountSeeder`.
2. Create a withdrawal. It remains `pending`.
3. Settle it locally:
```bash
curl -X POST http://localhost:8000/api/v2/simulator/transactions/TRANSACTION_UUID/settle \
  -H 'X-API-Key: YOUR_KEY' -H 'Content-Type: application/json' \
  -d '{"status":"success"}'
```
Use `fail` to simulate failure. On success, the local account balance is reduced and a movement is recorded. If a `callback_url` is present, the simulator POSTs a status payload and sends an `X-Simulator-Signature` HMAC header. This signature is specific to this simulator and is not claimed to match any provider callback signature.

Simulated deposit:
```bash
curl -X POST http://localhost:8000/api/v2/simulator/deposits \
  -H 'X-API-Key: YOUR_KEY' -H 'Content-Type: application/json' \
  -d '{"amount":"250.00","sender_name":"Demo Sender","sender_iban":"TR000000000000000000000000","receiver_iban":"TR000000000000000000000001","ext_transaction_id":"DEMO-DEP-1"}'
```
This creates a local successful deposit transaction, adds the amount to the matching local account balance, and writes a movement. It does not verify a real incoming transfer.

## Installation
1. Merge the package's `app/`, `config/`, `database/`, and `routes/` into the Laravel application.
2. Add the `.env.example` variables to your `.env`.
3. Register middleware alias `api.key`:
   - Laravel 11: inside `withMiddleware` in `bootstrap/app.php`, add `$middleware->alias(['api.key' => \\App\\Http\\Middleware\\ApiKeyMiddleware::class]);`
   - Laravel 10: in `app/Http/Kernel.php` add `'api.key' => \\App\\Http\\Middleware\\ApiKeyMiddleware::class` to `$middlewareAliases`.
4. Run `php artisan migrate`.
5. Optional demo data: `php artisan db:seed --class=SimulatorAccountSeeder`.

### URL prefix
Laravel normally prefixes `routes/api.php` routes with `/api`. Therefore the default URLs are `/api/v2/...`, `/api/health`, and `/api/ready`. To expose exact provider-style paths `/v2/...`, `/health`, and `/ready`, set the API route prefix to an empty string in your application's route registration. Laravel 11 supports `apiPrefix: ''` in `withRouting`; for Laravel 10, adjust the API prefix in `RouteServiceProvider`. Keep these routes in API middleware and do not expose them through web/CSRF middleware.

## Source fidelity and limitations
The supplied HTML clearly documents endpoint names, `X-API-Key`, required withdrawal fields, duplicate external ID protection, the pending withdrawal response example, callbacks, and broad error categories. It does not expose all 51 schema definitions as readable text in the extracted source. Consequently, list/inquiry/movement/transaction response details are best-effort local equivalents, not a guarantee of byte-for-byte parity for every undocumented field.

The simulator uses sample banks and sample accounts, and it cannot detect real deposits, connect to bank rails, create bank-issued receipts, or execute real transfers. `success` only means the simulation was marked successful. Do not use this system to represent real funds or financial settlement.


## Additional local banking-session and transfer endpoints

These are simulator-only extensions. They do not log into a real bank's mobile application and do not create a persistent real bank session.

| Method | Path | Required headers | Purpose |
|---|---|---|---|
| POST | `/api/v2/bank/login` | `X-API-Key` | Create a local demo session using configured demo credentials |
| GET | `/api/v2/bank/session` | `X-API-Key`, `X-Bank-Session` | Inspect session status and expiry |
| POST | `/api/v2/bank/session/refresh` | `X-API-Key`, `X-Bank-Session` | Extend a valid demo session by the configured TTL |
| DELETE | `/api/v2/bank/session` | `X-API-Key`, `X-Bank-Session` | Revoke a demo session |
| GET | `/api/v2/accounts/{id}/balance` | `X-API-Key`, `X-Bank-Session` | Read a simulated account balance |
| GET | `/api/v2/accounts/{id}/activity` | `X-API-Key`, `X-Bank-Session` | Read paginated account activity |
| POST | `/api/v2/transactions` | `X-API-Key`, `X-Bank-Session` | Create a simulated transfer, initially pending |

Configure `SIMULATOR_BANK_USERNAME`, `SIMULATOR_BANK_PASSWORD`, and `SIMULATOR_SESSION_TTL_MINUTES`. Defaults are for local development only; replace them before use. The raw session token is returned once; the database stores only its SHA-256 hash. Pass the token in `X-Bank-Session` or `Authorization: Bearer <token>`. Refresh before expiry; sessions intentionally do not remain active indefinitely.

Demo login request:
```json
{ "username": "demo", "password": "your-configured-demo-password", "bank_code": "garanti" }
```

Transfer request:
```json
{
  "ext_transaction_id": "LOCAL-TRANSFER-001",
  "account_id": 1,
  "receiver_iban": "TR000000000000000000000002",
  "receiver_name": "Demo Account Holder",
  "amount": "125.00",
  "description": "Local test transfer"
}
```

The transfer starts as `pending`. Use the protected `/api/v2/simulator/transactions/{id}/settle` route with `{"status":"success"}` to simulate completion. If the recipient IBAN matches a local demo account, the simulator credits that account and writes an incoming movement; otherwise it only records the outgoing transfer. The account debit is checked at settlement. No actual bank login, balance query, or transfer occurs.
