<?php
return [
    'api_key' => env('SIMULATOR_API_KEY', 'change-me'),
    'callback_secret' => env('SIMULATOR_CALLBACK_SECRET', 'change-me-too'),
    'currency' => env('SIMULATOR_CURRENCY', 'TRY'),
    'default_withdrawal_status' => env('SIMULATOR_DEFAULT_WITHDRAWAL_STATUS', 'pending'),
    'bank_username' => env('SIMULATOR_BANK_USERNAME', 'demo'),
    'bank_password' => env('SIMULATOR_BANK_PASSWORD', 'demo-change-me'),
    'session_ttl_minutes' => (int) env('SIMULATOR_SESSION_TTL_MINUTES', 30),
];
