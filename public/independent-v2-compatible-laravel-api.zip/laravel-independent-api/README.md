# Independent V2-Compatible Laravel API (Simulation Mode)

This project recreates the documented V2 HTTP contract locally. It makes **no external provider calls** and does not move real money. Withdrawals are stored locally as `pending`; use the simulator settlement endpoint or Artisan command to mark them `success` or `fail`. Deposits can be simulated through a protected endpoint.

## Requirements
- Laravel 10/11, PHP 8.1+, database configured in `.env` (MySQL/PostgreSQL/SQLite)
- `routes/api.php` in Laravel is automatically prefixed with `/api` in standard Laravel installations. This package registers `/v2/...`, so actual URLs are `/api/v2/...`.

## Install
1. Copy the `app`, `config`, `database`, and `routes` contents into your Laravel project (merge existing files; do not overwrite your whole `routes/api.php` or `config/app.php`).
2. Add to `.env`:

```dotenv
SIMULATOR_API_KEY=change-this-to-a-long-random-secret
SIMULATOR_CALLBACK_SECRET=change-this-too
SIMULATOR_CURRENCY=TRY
SIMULATOR_DEFAULT_WITHDRAWAL_STATUS=pending
SIMULATOR_BANK_USERNAME=demo
SIMULATOR_BANK_PASSWORD=replace-with-a-long-random-demo-password
SIMULATOR_SESSION_TTL_MINUTES=30
```

3. Register the middleware alias in `bootstrap/app.php` (Laravel 11) inside `withMiddleware`:

```php
$middleware->alias(['api.key' => \App\Http\Middleware\ApiKeyMiddleware::class]);
```
For Laravel 10, add `'api.key' => \App\Http\Middleware\ApiKeyMiddleware::class` to `$middlewareAliases` in `app/Http/Kernel.php`.

4. Run:

```bash
php artisan migrate
```

5. Send `X-API-Key: <SIMULATOR_API_KEY>` with all `/api/v2/*` requests.

## Routes
- `POST /api/v2/bank/login`, `GET /api/v2/bank/session`, `POST /api/v2/bank/session/refresh`, `DELETE /api/v2/bank/session` (local demo session only)
- `GET /api/v2/accounts/{id}/balance`, `GET /api/v2/accounts/{id}/activity`, `POST /api/v2/transactions` (require `X-Bank-Session` as well as API key)
- `GET /api/v2/banks`
- `GET /api/v2/accounts`
- `GET /api/v2/accounts/inquiry`
- `GET /api/v2/accounts/movements`
- `POST /api/v2/withdrawal/auto`
- `POST /api/v2/withdrawal/manual`
- `POST /api/v2/withdrawal/{id}/cancel`
- `GET /api/v2/transactions`
- `GET /api/v2/transactions/{id}`
- `GET /api/v2/transactions/{id}/receipt`
- `GET /api/health`, `GET /api/ready`
- Local simulator: `POST /api/v2/simulator/deposits`, `POST /api/v2/simulator/transactions/{id}/settle`

## Simulating a withdrawal
Create a withdrawal with the same request fields as the source API. It returns `201` and `status: pending`. To simulate a final result:

```bash
curl -X POST http://localhost:8000/api/v2/simulator/transactions/TRANSACTION_ID/settle \
  -H 'X-API-Key: YOUR_KEY' -H 'Content-Type: application/json' \
  -d '{"status":"success"}'
```
Use `"fail"` to simulate failure. The app updates the transaction and posts a callback to `callback_url` when provided. If the callback URL is unreachable, the transaction status remains updated; the response includes callback delivery status.

## Simulating a deposit
```bash
curl -X POST http://localhost:8000/api/v2/simulator/deposits \
  -H 'X-API-Key: YOUR_KEY' -H 'Content-Type: application/json' \
  -d '{"amount":"250.00","sender_name":"Demo Sender","sender_iban":"TR000000000000000000000000","receiver_iban":"TR000000000000000000000001","ext_transaction_id":"DEMO-DEP-1"}'
```
Creates a local deposit transaction and movement; no bank transfer occurs.

## Seed demo accounts
Create accounts through SQL/admin code or use the seeder:

```bash
php artisan db:seed --class=SimulatorAccountSeeder
```
The seeder is optional and intended for development only.

## Compatibility notes
- The documented endpoints, core request fields, `X-API-Key` auth, pending withdrawal response fields, duplicate external transaction ID protection, and callback types are represented.
- The source HTML does not expose every schema's full field definitions in its visible text. This implementation uses documented examples and sensible local simulation fields; exact undocumented response parity cannot be guaranteed.
- `GET /v2/accounts/inquiry` reports simulated platform account balances, not a real bank balance. `GET /v2/accounts/movements` reads local movements.
- This is a simulation. Do not use its successful transaction statuses as evidence that real money moved.

## Important limitation

The bank login/session endpoints authenticate against local demo credentials only. They do not automate or connect to a real mobile banking APK. Session refresh extends a local session for a configured period; it does not guarantee a permanent session. All balances and transactions are simulated.
