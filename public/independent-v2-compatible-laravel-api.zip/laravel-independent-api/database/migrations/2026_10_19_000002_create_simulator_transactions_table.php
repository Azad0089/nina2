<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { Schema::create('simulator_transactions', function(Blueprint $t){ $t->id(); $t->uuid('uuid')->unique(); $t->string('ext_transaction_id')->unique(); $t->string('type'); $t->string('status')->default('pending')->index(); $t->decimal('amount',18,2); $t->string('currency',3)->default('TRY'); $t->string('sender_iban')->nullable(); $t->unsignedBigInteger('sender_account_id')->nullable(); $t->string('receiver_iban')->nullable(); $t->string('receiver_name')->nullable(); $t->text('description')->nullable(); $t->text('callback_url')->nullable(); $t->json('metadata')->nullable(); $t->timestamp('completed_at')->nullable(); $t->timestamps(); $t->index(['type','created_at']); }); } public function down(): void { Schema::dropIfExists('simulator_transactions'); } };
