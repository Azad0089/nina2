<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { Schema::create('simulator_movements', function(Blueprint $t){ $t->id(); $t->unsignedBigInteger('account_id')->nullable()->index(); $t->unsignedBigInteger('transaction_id')->nullable()->index(); $t->string('direction'); $t->decimal('amount',18,2); $t->text('description')->nullable(); $t->string('counterparty_iban')->nullable(); $t->string('counterparty_name')->nullable(); $t->timestamp('occurred_at')->nullable()->index(); $t->timestamps(); }); } public function down(): void { Schema::dropIfExists('simulator_movements'); } };
