<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(): void { Schema::create('simulator_accounts', function(Blueprint $t){ $t->id(); $t->string('name'); $t->string('bank_code')->nullable(); $t->string('iban')->unique(); $t->string('account_holder'); $t->decimal('balance',18,2)->default(0); $t->boolean('is_active')->default(true); $t->json('capabilities')->nullable(); $t->timestamps(); }); } public function down(): void { Schema::dropIfExists('simulator_accounts'); } };
