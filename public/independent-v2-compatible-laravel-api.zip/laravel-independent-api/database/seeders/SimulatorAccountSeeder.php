<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\SimulatorAccount;
class SimulatorAccountSeeder extends Seeder
{
    public function run(): void
    {
        $accounts=[
            ['name'=>'Demo Garanti Account','bank_code'=>'garanti','iban'=>'TR000000000000000000000001','account_holder'=>'Demo Account Holder','balance'=>'100000.00','is_active'=>true,'capabilities'=>['deposits'=>true,'withdrawals'=>true]],
            ['name'=>'Demo Isbank Account','bank_code'=>'isbank','iban'=>'TR000000000000000000000002','account_holder'=>'Demo Account Holder','balance'=>'50000.00','is_active'=>true,'capabilities'=>['deposits'=>true,'withdrawals'=>true]],
        ];
        foreach($accounts as $account) SimulatorAccount::updateOrCreate(['iban'=>$account['iban']],$account);
    }
}
