<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\SimulatorApiController;

Route::prefix('v2')->middleware('api.key')->group(function () {
    Route::post('/bank/login',[SimulatorApiController::class,'bankLogin']);
    Route::get('/bank/session',[SimulatorApiController::class,'bankSession']);
    Route::post('/bank/session/refresh',[SimulatorApiController::class,'refreshBankSession']);
    Route::delete('/bank/session',[SimulatorApiController::class,'bankLogout']);
    Route::get('/banks',[SimulatorApiController::class,'banks']);
    Route::get('/accounts',[SimulatorApiController::class,'accounts']);
    Route::get('/accounts/inquiry',[SimulatorApiController::class,'inquiry']);
    Route::get('/accounts/{id}/balance',[SimulatorApiController::class,'accountBalance']);
    Route::get('/accounts/{id}/activity',[SimulatorApiController::class,'accountActivity']);
    Route::post('/transactions',[SimulatorApiController::class,'createTransfer']);
    Route::get('/accounts/movements',[SimulatorApiController::class,'movements']);
    Route::post('/withdrawal/auto',[SimulatorApiController::class,'autoWithdrawal']);
    Route::post('/withdrawal/manual',[SimulatorApiController::class,'manualWithdrawal']);
    Route::post('/withdrawal/{id}/cancel',[SimulatorApiController::class,'cancelWithdrawal']);
    Route::get('/transactions',[SimulatorApiController::class,'transactions']);
    Route::get('/transactions/{id}/receipt',[SimulatorApiController::class,'receipt']);
    Route::get('/transactions/{id}',[SimulatorApiController::class,'transaction']);
    Route::post('/simulator/deposits',[SimulatorApiController::class,'simulateDeposit']);
    Route::post('/simulator/transactions/{id}/settle',[SimulatorApiController::class,'settle']);
});
Route::get('/health',[SimulatorApiController::class,'health']);
Route::get('/ready',[SimulatorApiController::class,'ready']);
