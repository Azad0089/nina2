<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SupportTicket extends Model
{
    protected $fillable = [
        'user_id',
        'name',
        'email',
        'topic',
        'message',
        'admin_reply',
        'status',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
